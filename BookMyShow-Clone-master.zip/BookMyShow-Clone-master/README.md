BookMyShow-Clone
Similar website like BMS created using Django.

Screenshots:

Movie Filter Page

![movies](https://user-images.githubusercontent.com/25791233/58645128-5a60db80-8320-11e9-816d-a89be8d257d1.png)

Movie Detail Page

![movie-detail](https://user-images.githubusercontent.com/25791233/58645207-82e8d580-8320-11e9-8daa-177276773dcc.png)

Theatre List Page

![theatre-list](https://user-images.githubusercontent.com/25791233/58645242-985dff80-8320-11e9-9a6c-610e952f6c77.png)

Booking Page

![seat-booking](https://user-images.githubusercontent.com/25791233/58645276-aa3fa280-8320-11e9-82ab-8fd3710b4529.png)
